//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by RibbonMDIDemo.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDS_WINDOWS_MANAGER             107
#define IDB_WRITE                       116
#define IDB_WRITELARGE                  117
#define IDR_MAINFRAME                   128
#define IDR_RIBBONTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDR_POPUP_MDITABS               132
#define IDR_POPUP_DROP_MDITABS          133
#define IDB_WORKSPACE                   147
#define IDB_TOOLBAR256                  151
#define IDR_PASTE_MENU                  151
#define IDR_WINDOWS_MENU                152
#define IDB_MAIN                        154
#define IDB_BUTTONS                     156
#define IDB_FILELARGE                   169
#define IDB_FILESMALL                   170
#define IDC_COMPANY_URL                 1041
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_VIEW_WORKSPACE2              32792
#define ID_VIEW_WORKSPACE               32803
#define ID_VIEW_OUTPUT                  32804
#define ID_WINDOW_MANAGER               32823
#define ID_VIEW_APPLOOK_2000            32833
#define ID_VIEW_APPLOOK_XP              32834
#define ID_VIEW_APPLOOK_2003            32835
#define ID_VIEW_APPLOOK_WIN_XP          32836
#define ID_VIEW_APPLOOK_VS2005          32837
#define ID_VIEW_APPLOOK_2007            32838
#define ID_MDI_NEW_VERT_GROUP           32839
#define ID_MDI_NEW_HORZ_TAB_GROUP       32840
#define ID_MDI_MOVE_TO_PREV_GROUP       32841
#define ID_MDI_CANCEL                   32842
#define ID_MDI_MOVE_TO_NEXT_GROUP       32843
#define ID_WRITE_PASTEASHYPERLINK       33015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        157
#define _APS_NEXT_COMMAND_VALUE         32844
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
