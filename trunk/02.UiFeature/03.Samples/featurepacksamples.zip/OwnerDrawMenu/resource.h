//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by OwnerDrawMenu.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDS_MAIN_TOOLBAR                101
#define IDR_MAINFRAME                   128
#define IDR_OWNERDTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDR_LINE_STYLE_POPUP            151
#define IDD_ABOUTBOX                    999
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_LINE_STYLE_1                 32822
#define ID_LINE_STYLE_2                 32823
#define ID_LINE_STYLE_3                 32824
#define ID_LINE_STYLE_4                 32825
#define ID_LINE_STYLE_5                 32826
#define ID_LINE_STYLE_6                 32827
#define ID_LINE_STYLE_7                 32828
#define ID_LINE_STYLE_8                 32829
#define ID_LINE_STYLE_9                 32830
#define ID_LINE_STYLE_10                32831
#define ID_MORE_LINES                   32832
#define ID_LINE_STYLE_MENU              32833

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         32834
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
