//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StateCollection.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDS_MAIN_TOOLBAR                101
#define IDR_MAINFRAME                   128
#define IDR_STATECTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDB_WORKSPACE                   147
#define IDC_COMPANY_URL                 1041
#define IDD_ABOUTBOX                    999
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_VIEW_WORKSPACE               32803
#define ID_VIEW_OUTPUT                  32804
#define ID_TOOLS_ENTRY                  32805
#define ID_USER_TOOL1                   32806
#define ID_USER_TOOL2                   32807
#define ID_USER_TOOL3                   32808
#define ID_USER_TOOL4                   32809
#define ID_USER_TOOL5                   32810
#define ID_USER_TOOL6                   32811
#define ID_USER_TOOL7                   32812
#define ID_USER_TOOL8                   32813
#define ID_USER_TOOL9                   32814
#define ID_USER_TOOL10                  32815
#define ID_SAVE_DEBUG_CONF              32822
#define ID_SAVE_REGULAR_CONF            32823
#define ID_LOAD_DEBUG_CONF              32824
#define ID_LOAD_REGULAR_CONF            32825

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32826
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
