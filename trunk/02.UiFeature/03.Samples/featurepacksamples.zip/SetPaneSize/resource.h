//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SetPaneSize.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDD_SetPaneSize_FORM             101
#define IDS_MAIN_TOOLBAR                101
#define IDR_MAINFRAME                   128
#define IDR_SETBARTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDB_WORKSPACE                   147
#define IDB_TOOLBAR256                  151
#define IDD_DLG_BAR                     154
#define IDD_ABOUTBOX                    999
#define IDC_COMPANY_URL                 1041
#define IDC_EDIT_SIZE                   1042
#define IDC_EDIT_WIDTH                  1043
#define IDC_BUTTON_SET_DLGBAR_SIZE      1044
#define IDC_BUTTON_SET_CONTAINER_SIZE   1045
#define IDC_EDIT_WIDTH_IN_PIXELS        1047
#define IDC_EDIT_HEIGHT_IN_PIXELS       1048
#define IDC_BTN_SET_WIDTH_IN_PIXELS		1049
#define IDC_BTN_SET_HEIGHT_IN_PIXELS	1050
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_VIEW_DLGBAR                  32792
#define ID_VIEW_WORKSPACE               32803

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        155
#define _APS_NEXT_COMMAND_VALUE         32833
#define _APS_NEXT_CONTROL_VALUE         1051
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
