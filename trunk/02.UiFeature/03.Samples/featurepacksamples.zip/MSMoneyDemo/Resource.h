//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MSMoneyDemo.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_MSMONETYPE              129
#define IDB_MENU_IMAGES                 134
#define IDR_FORWARD_MENU                144
#define IDR_BACKWARD_MENU               145
#define IDB_PRESSEDTOOLBAR              146
#define IDB_MSM_VIEW_BKGND          147
#define IDB_COLDTOOLBAR                 261
#define IDB_HOTTOOLBAR                  262
#define IDB_DISABLEDTOOLBAR             263
#define IDB_MENU_IMAGES_16              264
#define IDS_BACK                        748
#define IDS_FORWARD                     749
#define IDS_STOP                        750
#define IDS_REFRESH                     751
#define IDC_MAIL                        1000
#define IDC_URL                         1001
#define IDC_VERSION                     1002
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_STOP                    32778
#define ID_VIEW_REFRESH                 32779
#define ID_GO_BACK                      32787
#define ID_GO_FORWARD                   32788
#define ID_GO_ADDRESS                   32830
#define ID_GO_ADDRESS_EDIT              32831
#define ID_CATEGORIE_1                  32832
#define ID_CATEGORIE_2                  32833
#define ID_CATEGORIE_3                  32834
#define ID_CATEGORIE_4                  32835
#define ID_CATEGORIE_5                  32836
#define ID_CATEGORIE_6                  32837
#define ID_CATEGORIE_7                  32838
#define ID_CATEGORIE_8                  32839
#define ID_LINKS_HOME_1                 32840
#define ID_LINKS_HOME_2                 32841
#define ID_LINKS_BANKING_1              32842
#define ID_LINKS_BANKING_2              32843
#define ID_LINKS_BANKING_3              32844
#define ID_LINKS_BANKING_4              32845
#define ID_LINKS_BANKING_5              32846
#define ID_LINKS_BILLS_1                32847
#define ID_LINKS_BILLS_2                32848
#define ID_LINKS_BILLS_3                32849
#define ID_LINKS_BILLS_4                32850
#define ID_LINKS_BILLS_5                32851
#define ID_LINKS_REPORTS_1              32852
#define ID_LINKS_REPORTS_2              32853
#define ID_LINKS_REPORTS_3              32854
#define ID_LINKS_BUDGET_1               32855
#define ID_LINKS_BUDGET_2               32856
#define ID_LINKS_INVESTING_1            32857
#define ID_LINKS_INVESTING_2            32858
#define ID_LINKS_INVESTING_3            32859
#define ID_LINKS_INVESTING_4            32860
#define ID_LINKS_INVESTING_5            32861
#define ID_LINKS_INVESTING_6            32862
#define ID_LINKS_INVESTING_7            32863
#define ID_LINKS_PLANNING_1             32864
#define ID_LINKS_PLANNING_2             32865
#define ID_LINKS_PLANNING_3             32866
#define ID_LINKS_PLANNING_4             32867
#define ID_LINKS_PLANNING_5             32868
#define ID_LINKS_PLANNING_6             32869
#define ID_LINKS_TAXES_1                32870
#define ID_LINKS_TAXES_2                32871
#define ID_LINKS_TAXES_3                32872
#define ID_LINKS_TAXES_4                32873
#define ID_LINKS_TAXES_5                32874
#define ID_TOOLBAR_CUSTOMIZE            32875
#define ID_FORWARD_1                    32876
#define ID_FORWARD_2                    32877
#define ID_BACKWARD_1                   32878
#define ID_BACKWARD_2                   32879
#define ID_HELP_MICROSOFT               32880

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        148
#define _APS_NEXT_COMMAND_VALUE         32881
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
