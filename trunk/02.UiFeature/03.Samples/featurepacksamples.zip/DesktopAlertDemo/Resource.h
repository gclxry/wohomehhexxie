//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DesktopAlertDemo.rc
//
#define IDD_ALERT_DIALOG                102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDI_MAIL                        130
#define IDD_DIALOG2                     130
#define IDB_FLAG                        132
#define IDB_DELETE                      133
#define IDB_LOGO                        134
#define IDR_POPUP                       136
#define IDB_ICONS                       145
#define IDB_ICONS_SMALL                 146
#define IDR_TOOLBAR1                    147
#define IDB_MENUIMAGES                  149
#define IDC_SHOW                        1000
#define IDC_BUTTON1                     1003
#define IDC_VISUAL_MNGR                 1004
#define IDC_ANIMATION                   1005
#define IDC_ANIM_SPEED                  1006
#define IDC_ANIM_SPEED_VAL              1007
#define IDC_TRANSP                      1008
#define IDC_FLAG                        1008
#define IDC_TRANSP_VAL                  1009
#define IDC_DELETE                      1009
#define IDC_FROM                        1010
#define IDC_AUTOCLOSE_TIME              1010
#define IDC_SMALL_CAPTION               1011
#define IDC_OPTIONS                     1012
#define IDC_AUTOCLOSE_VAL               1012
#define IDC_POPUP_SOURCE                1013
#define IDC_POPUP_SOURCE2               1014
#define IDC_ICONS                       1016
#define IDC_ICON_LABEL                  1017
#define IDC_TEXT_LABEL                  1018
#define IDC_TEXT                        1019
#define IDC_URL_LABEL                   1020
#define IDC_LINK                        1021
#define IDC_AUTO_CLOSE                  1022
#define ID_POPUP_OPENITEM               32771
#define ID_POPUP_FLAGITEM               32772
#define ID_POPUP_DELETEITEM             32773
#define ID_POPUP_MARKASREAD             32774
#define ID_POPUP_DISABLENEWDESKTOPALERT 32775
#define ID_POPUP_DESKTOPALERTSETTINGS   32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        150
#define _APS_NEXT_COMMAND_VALUE         32779
#define _APS_NEXT_CONTROL_VALUE         1023
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
