//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by StatusBarDemo.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDD_STATUSBARDEMO_FORM          101
#define IDS_MAIN_TOOLBAR                101
#define ID_INDICATOR_ICON               102
#define ID_INDICATOR_PROGRESS           103
#define ID_INDICATOR_LABEL              104
#define ID_INDICATOR_ANIMATION          105
#define IDR_MAINFRAME                   128
#define IDR_STATUSTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDB_ANIMATION                   154
#define IDB_ICON1                       155
#define IDB_ICON2                       156
#define IDD_ABOUTBOX                    999
#define IDC_COMPANY_URL                 1041
#define IDC_START_PROGRESS              1043
#define IDC_START_ANIMATION             1044
#define IDC_ICON1                       1045
#define IDC_ICON2                       1046
#define IDC_TEXT_COLOR                  1047
#define IDC_BACK_COLOR                  1048
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        156
#define _APS_NEXT_COMMAND_VALUE         32833
#define _APS_NEXT_CONTROL_VALUE         1048
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
