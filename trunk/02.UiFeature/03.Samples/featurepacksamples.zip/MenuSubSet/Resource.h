//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MenuSubSet.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_MENUSUBSET_FORM             101
#define IDS_WINDOWS_MANAGER             107
#define IDR_MAINFRAME                   128
#define IDR_MENUSUTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDB_TOOLBAR256                  151
#define IDD_SELECT_CONF                 154
#define IDC_COMPANY_URL                 1041
#define IDC_CONF1                       1042
#define IDC_CONF2                       1043
#define IDC_CONF3                       1044
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_WINDOW_MANAGER               32823
#define ID_VIEW_APPLOOK_2000            32833
#define ID_VIEW_APPLOOK_XP              32834
#define ID_VIEW_APPLOOK_2003            32835
#define ID_VIEW_APPLOOK_WIN_XP          32836
#define ID_VIEW_APPLOOK_VS2005          32837
#define ID_VIEW_APPLOOK_2007            32838
#define ID_DEMO_DEMO1                   32844
#define ID_DEMO_DEMO2                   32845

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        155
#define _APS_NEXT_COMMAND_VALUE         32846
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
