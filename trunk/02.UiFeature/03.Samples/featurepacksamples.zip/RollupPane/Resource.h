//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by RollupPane.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDS_MAIN_TOOLBAR                101
#define IDR_MAINFRAME                   128
#define IDR_RollupControlBaTYPE         129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDB_TOOLBAR256                  151
#define IDD_ABOUTBOX                    999
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771
#define ID_VIEW_USER_TOOLBAR1           32793
#define ID_VIEW_USER_TOOLBAR2           32794
#define ID_VIEW_USER_TOOLBAR3           32795
#define ID_VIEW_USER_TOOLBAR4           32796
#define ID_VIEW_USER_TOOLBAR5           32797
#define ID_VIEW_USER_TOOLBAR6           32798
#define ID_VIEW_USER_TOOLBAR7           32799
#define ID_VIEW_USER_TOOLBAR8           32800
#define ID_VIEW_USER_TOOLBAR9           32801
#define ID_VIEW_USER_TOOLBAR10          32802
#define ID_VIEW_APPLOOK_2000            32826
#define ID_VIEW_APPLOOK_XP              32827
#define ID_VIEW_APPLOOK_2003            32828
#define ID_VIEW_APPLOOK_WIN_XP          32829
#define ID_VIEW_APPLOOK_VS2005          32830
#define ID_VIEW_APPLOOK_2007            32831
#define ID_VIEW_APPLOOK_2007_1          32832
#define ID_VIEW_APPLOOK_2007_2          32833
#define ID_VIEW_APPLOOK_2007_3          32834
#define ID_VIEW_INFOBAR                 32835

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        160
#define _APS_NEXT_COMMAND_VALUE         32850
#define _APS_NEXT_CONTROL_VALUE         1042
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
