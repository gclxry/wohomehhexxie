//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DrawClient.rc
//
#define IDR_MAINFRAME                   2
#define IDR_DRAWCLTYPE                  3
#define IDR_DRAWCLTYPE_CNTR_IP          6
#define IDP_BUSY                        100
#define IDP_OLE_INIT_FAILED             101
#define IDD_PROP_RECT                   101
#define IDP_FAILED_TO_CREATE            102
#define IDC_WEIGHT                      102
#define IDC_PENCIL                      102
#define IDC_NOFILL                      103
#define ID_POPUP_MENU                   103
#define IDC_SPIN1                       104
#define IDD_SUMM_PAGE                   104
#define IDC_AUTHOR                      105
#define IDD_STAT_PAGE                   105
#define IDC_KEYWORDS                    106
#define IDC_COMMENTS                    107
#define IDC_TITLE                       108
#define IDC_SUBJECT                     109
#define IDC_TEMPLATE                    110
#define IDB_RIBBON_MAIN                 110
#define IDC_SAVEDBY                     111
#define IDC_REVNUM                      112
#define IDB_RIBBON_FILELARGE            112
#define IDC_EDITTIME                    113
#define IDB_RIBBON_FILESMALL            113
#define IDC_LASTPRINT                   114
#define IDC_CREATEDATE                  115
#define IDC_LASTSAVE                    116
#define IDR_THEME_MENU                  116
#define IDC_NUMPAGES                    117
#define IDB_RIBBON_ICONS                117
#define IDC_NUMWORDS                    118
#define IDR_WINDOWS_MENU                118
#define IDC_NUMCHARS                    119
#define IDR_POPUP_MDITABS               119
#define IDC_APPNAME                     120
#define IDR_POPUP_DROP_MDITABS          120
#define IDC_SECURITY                    122
#define IDC_THUMBNAIL                   123
#define IDR_PROPERTY                    123
#define IDR_PROPERTIES                  123
#define IDB_RIBBON_HOMELARGE            126
#define IDB_RIBBON_HOMESMALL            127
#define IDB_RIBBON_VIEWSMALL            128
#define IDB_RIBBON_VIEWLARGE            129
#define IDB_STATUSBAR_1                 130
#define IDB_STATUSBAR_2                 131
#define IDB_RIBBON_FORMATLARGE          132
#define IDB_RIBBON_FORMATSMALL          133
#define IDB_LINEWEIGHT                  134
#define IDD_LINEWEIGHT                  135
#define IDB_STYLES                      136
#define IDD_ABOUTBOX                    999
#define ID_CANCEL_EDIT                  32768
#define ID_VIEW_GRID                    32769
#define ID_DRAW_SELECT                  32770
#define ID_DRAW_LINE                    32771
#define ID_DRAW_RECT                    32772
#define ID_DRAW_ROUNDRECT               32773
#define ID_DRAW_ELLIPSE                 32774
#define ID_OBJECT_LINECOLOR             32775
#define ID_OBJECT_FILLCOLOR             32776
#define ID_OBJECT_MOVETOFRONT           32777
#define ID_OBJECT_MOVETOBACK            32778
#define ID_OBJECT_MOVEFORWARD           32779
#define ID_OBJECT_MOVEBACK              32780
#define ID_VIEW_PAPERCOLOR              32781
#define ID_DRAW_POLYGON                 32782
#define ID_VIEW_SHOWOBJECTS             32784
#define ID_FILE_SUMMARYINFO             32792
#define ID_WINDOWS_MENU                 32793
#define ID_WINDOW_WINDOWS               32812
#define ID_WINDOW_MANAGER               32813
#define ID_VIEW_APPLOOK_2007            32818
#define ID_VIEW_APPLOOK_2007_1          32819
#define ID_VIEW_APPLOOK_2007_2          32820
#define ID_VIEW_APPLOOK_2007_3          32821
#define ID_NEWWINDOW                    32823
#define ID_MDI_NEW_HORZ_TAB_GROUP       32824
#define ID_MDI_NEW_VERT_GROUP           32825
#define ID_MDI_MOVE_TO_NEXT_GROUP       32826
#define ID_MDI_MOVE_TO_PREV_GROUP       32827
#define ID_MDI_CANCEL                   32828
#define ID_EXPAND                       32829
#define ID_SORTINGGROUP                 32830
#define ID_STATUSBAR_PANE_OBJECTCOUNT   32831
#define ID_STATUSBAR_PANE_SELECTEDOBJECTCOUNT 32832
#define ID_TOOLS_OPTIONS                32833
#define ID_OBJECT_NOFILL                32834
#define ID_OBJECT_LINEWEIGHT            32835
#define ID_OBJECT_LINEWEIGHT_MORE       32836
#define ID_OBJECT_PROPERTIES            32838
#define ID_OBJECT_NOLINE                32839
#define ID_OBJECT_STYLES                32840

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32841
#define _APS_NEXT_CONTROL_VALUE         124
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
