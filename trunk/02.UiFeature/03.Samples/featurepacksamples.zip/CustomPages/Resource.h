//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CustomPages.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDS_MAIN_TOOLBAR                101
#define IDR_MAINFRAME                   128
#define IDR_CUSTOMTYPE                  129
#define IDR_CONTEXT_MENU                130
#define IDR_POPUP_TOOLBAR               131
#define IDD_CUST_PAGE_DLG               151
#define IDD_ABOUTBOX                    1000
#define IDC_CHECK1                      1041
#define IDC_CHECK2                      1042
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_TOOLBARS                32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        152
#define _APS_NEXT_COMMAND_VALUE         32822
#define _APS_NEXT_CONTROL_VALUE         1043
#define _APS_NEXT_SYMED_VALUE           107
#endif
#endif
