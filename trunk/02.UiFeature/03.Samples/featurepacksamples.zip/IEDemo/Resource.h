//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IEDemo.rc
//
#define IDP_OLE_INIT_FAILED             100
#define IDS_MAIN_TOOLBAR                101
#define ID_INDICATOR_ICON               102
#define ID_INDICATOR_PROGRESS           103
#define IDP_SOCKETS_INIT_FAILED         104
#define IDR_MAINFRAME                   128
#define IDR_IEDTYPE						129
#define IDR_MAINFRAME2                  129
#define IDR_POPUP_TOOLBAR               131
#define IDR_FONT_POPUP                  132
#define IDR_MFCAVI                      132
#define IDR_FAVORITES_POPUP             133
#define IDR_HISTORY_POPUP               134
#define IDB_MENU_IMAGES                 134
#define IDR_TOOLBAR_IMAGE_COLLECTION    138
#define IDB_IMAGE_COLLECTION            140
#define IDB_STATUS_READY                141
#define IDB_STATUS_ANIMATION            142
#define IDB_COLDTOOLBAR                 261
#define IDB_HOTTOOLBAR                  262
#define IDB_IMAGE_COLLECTION_SMALL      263
#define IDB_MENU_IMAGES_16              264
#define IDS_WEB_TUTORIAL                736
#define IDS_ONLINE_SUPPORT              737
#define IDS_FREE_STUFF                  738
#define IDS_INTERNET_START_PAGE         743
#define IDS_BEST_OF_THE_WEB             745
#define IDS_MICROSOFT_HOME_PAGE         747
#define IDS_BACK                        748
#define IDS_FORWARD                     749
#define IDS_STOP                        750
#define IDS_REFRESH                     751
#define IDS_HOME                        752
#define IDS_SEARCH                      753
#define IDS_FAVORITES                   754
#define IDS_PRINT                       755
#define IDS_FONT                        756
#define IDS_ADDRESS                     757
#define IDS_LINKS                       758
#define IDD_ABOUTBOX                    999
#define IDC_MAIL                        1000
#define IDC_URL                         1001
#define IDC_VERSION                     1002
#define IDC_TREE1                       1003
#define IDS_FILETYPES                   1201
#define ID_VIEW_ADDRESS_BAR             32722
#define ID_VIEW_CUSTOMIZE               32770
#define ID_VIEW_STOP                    32778
#define ID_VIEW_REFRESH                 32779
#define ID_LINK_1                       32781
#define ID_VIEW_FONTS_LARGEST           32782
#define ID_VIEW_FONTS_LARGE             32783
#define ID_VIEW_FONTS_MEDIUM            32784
#define ID_VIEW_FONTS_SMALL             32785
#define ID_VIEW_FONTS_SMALLEST          32786
#define ID_GO_BACK                      32787
#define ID_GO_FORWARD                   32788
#define ID_GO_START_PAGE                32789
#define ID_GO_SEARCH_THE_WEB            32790
#define ID_GO_BEST_OF_THE_WEB           32791
#define ID_FAVORITES_DROPDOWN           32792
#define ID_FONT_DROPDOWN                32793
#define ID_HELP_WEB_TUTORIAL            32798
#define ID_HELP_ONLINE_SUPPORT          32800
#define ID_FAVORITS_DUMMY               32819
#define ID_HISTORY_DUMMY                32820
#define ID_VIEW_LINKS_BAR               32821
#define ID_VIEW_TEXTLABELS              32823
#define ID_VIEW_EXPLORERBAR             32825
#define ID_LINK_MSDN					32826
#define ID_LINK_MICROSOFT               32827
#define ID_LINK_VISUALCPP               32828

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32830
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
