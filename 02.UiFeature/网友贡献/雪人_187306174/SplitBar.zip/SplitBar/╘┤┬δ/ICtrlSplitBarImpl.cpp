#include "StdAfx.h"
#include "ICtrlSplitBarImpl.h"
#include "..\..\Inc\UiFeatureDefs.h"

// ��갴�±�־
#define MOUSE_FLAG_DOWN								(0x0000001UL)

ICtrlSplitBar::ICtrlSplitBar(IUiFeatureKernel *pUiKernel) : ICtrlInterface(pUiKernel) {}

ICtrlSplitBarImpl::ICtrlSplitBarImpl(IUiFeatureKernel *pUiKernel) : ICtrlSplitBar(pUiKernel)
{
	// ���ӿؼ�������3�����ں�ϵͳע��ؼ�
	SetObjectType(CTRL_NAME_SPLITBAR);
	m_bHaveSysTipsProp = false;

	m_bTracking = FALSE;
	m_nSplitPos = 0;

	m_mouseFlag = 0;

	m_enumSplitSate = SplitStateNormal;
	for (int i = 0; i < RadioStateNum; i++)
	{
		m_pImage[i] = NULL;
		m_pGraphic[i] = NULL;
	}

	m_pIsHorz = NULL;
	m_pTopLeftMin = NULL;
	m_pRightBottomMin = NULL;
	m_pTopLeftName = NULL;
	m_pRightBottomName = NULL;
	m_pGraphLength = NULL;

}

ICtrlSplitBarImpl::~ICtrlSplitBarImpl()
{

}

bool ICtrlSplitBarImpl::CreateControlPropetry(bool bIsNewCtrl)
{
	IPropertyGroup *pImageGroup = (IPropertyGroup*)CreatePropetry(NULL, OTID_GROUP, "ImageGroup", "");
	IPropertyGroup *pNormalImageGroup = (IPropertyGroup*)CreatePropetry(pImageGroup,OTID_GROUP,"Normal","");
	IPropertyGroup *pHotImageGroup = (IPropertyGroup*)CreatePropetry(pImageGroup,OTID_GROUP,"Hot","");
	IPropertyGroup *pPressImageGroup = (IPropertyGroup*)CreatePropetry(pImageGroup,OTID_GROUP,"Press","");
	IPropertyGroup *pDisableImageGroup = (IPropertyGroup*)CreatePropetry(pImageGroup,OTID_GROUP,"Disable","");

	IPropertyGroup *pSplitGroup = (IPropertyGroup*)CreatePropetry(NULL, OTID_GROUP, "SplitGroup", "");

	m_pImage[SplitStateNormal] = (IPropertyImage*)CreatePropetry(pNormalImageGroup, OTID_IMAGE, "Image", "����״̬�ı���ͼƬ");
	m_pGraphic[SplitStateNormal] = (IPropertyImage*)CreatePropetry(pNormalImageGroup, OTID_IMAGE, "Graphic", "����״̬��ͼ�꣬Ĭ��ˮƽ�;��ж���");

	m_pImage[SplitStateHot] = (IPropertyImage*)CreatePropetry(pHotImageGroup, OTID_IMAGE, "Image", "����״̬�ı���ͼƬ");
	m_pGraphic[SplitStateHot] = (IPropertyImage*)CreatePropetry(pHotImageGroup, OTID_IMAGE, "Graphic", "����״̬��ͼ�꣬Ĭ��ˮƽ�;��ж���");

	m_pImage[SplitStatePressed] = (IPropertyImage*)CreatePropetry(pPressImageGroup, OTID_IMAGE, "Image", "����״̬�ı���ͼƬ");
	m_pGraphic[SplitStatePressed] = (IPropertyImage*)CreatePropetry(pPressImageGroup, OTID_IMAGE, "Graphic", "����״̬��ͼ�꣬Ĭ��ˮƽ�;��ж���");

	m_pImage[SplitStateDisabled] = (IPropertyImage*)CreatePropetry(pDisableImageGroup, OTID_IMAGE, "Image", "����״̬�ı���ͼƬ");
	m_pGraphic[SplitStateDisabled] = (IPropertyImage*)CreatePropetry(pDisableImageGroup, OTID_IMAGE, "Graphic", "����״̬��ͼ�꣬Ĭ��ˮƽ�;��ж���");

	m_pIsHorz = (IPropertyBool*)CreatePropetry(pSplitGroup, OTID_BOOL, "IsHorz", "�Ƿ���ˮƽ�ָ���");
	m_pTopLeftMin = (IPropertyInt*)CreatePropetry(pSplitGroup, OTID_INT, "TopLeftMin", "��һ�ָ��������Сֵ");
	m_pRightBottomMin = (IPropertyInt*)CreatePropetry(pSplitGroup, OTID_INT, "RightBottomMin", "�ڶ��ָ��������Сֵ");
	m_pTopLeftName = (IPropertyString*)CreatePropetry(pSplitGroup, OTID_STRING, "TopLeftName", "��һ�ָ������Panel����");
	m_pRightBottomName = (IPropertyString*)CreatePropetry(pSplitGroup, OTID_STRING, "RightBottomName", "�ڶ��ָ������Panel����");

	m_pGraphLength = (IPropertyInt*)CreatePropetry(pSplitGroup, OTID_INT, "GraphLength", "ͼ��ĳ���");
	m_pCursor = (IPropertyCursor*)CreatePropetry(pSplitGroup, OTID_CURSOR, "Cursor", "��קʱ�Ĺ��");

	return TRUE;
}

// Ϊ��������Ŀ�����¼��ݣ���չ�ؼ���ִ������ӿڣ�ÿ���ؼ�������ʵ�֣���ʵ�ֿ���Ϊ��
LRESULT ICtrlSplitBarImpl::ExecuteControlCommand(int nCommandId, WPARAM wParam, LPARAM lParam)
{
	return S_OK;
}

void ICtrlSplitBarImpl::OnCreate()
{

}

void ICtrlSplitBarImpl::OnFinalCreate()
{

}

void ICtrlSplitBarImpl::OnDestroy()
{

}

void ICtrlSplitBarImpl::OnPaint(CDrawingBoard &DrawBoard)
{
	if (IsEnable())
	{
		if (m_enumSplitSate ==  SplitStateDisabled)
		{
			m_enumSplitSate = SplitStateNormal;
		}
	}
	else
	{
		m_enumSplitSate = SplitStateDisabled;
	}

	SPLITBARSTATE SplitSate = m_enumSplitSate;

	RECT rcClient = GetClientRect();

	if (m_pImage[SplitSate]!=NULL)
	{
		m_pImage[SplitSate]->DrawImage(DrawBoard,rcClient);
	}

	if (m_pGraphic[SplitSate]!=NULL)
	{
		SIZE graphicSize = m_pGraphic[SplitSate]->GetImageSize();
		if (m_pIsHorz->GetValue())
		{
			graphicSize.cx+=m_pGraphLength->GetValue();
		}
		else
		{
			graphicSize.cy+=m_pGraphLength->GetValue();
		}
		RECT rcGraphicImage = {0};
		rcGraphicImage.left = (rcClient.right - rcClient.left)/2 - (graphicSize.cx/2);
		rcGraphicImage.top = (rcClient.bottom - rcClient.top)/2 - (graphicSize.cy/2);
		rcGraphicImage.right = rcGraphicImage.left + graphicSize.cx;
		rcGraphicImage.bottom = rcGraphicImage.top+graphicSize.cy;
		

		m_pGraphic[SplitSate]->DrawImage(DrawBoard,rcGraphicImage);
	}
}

void ICtrlSplitBarImpl::OnMouseMove(POINT pt)
{
	
}

void ICtrlSplitBarImpl::OnMouseEnter(POINT pt)
{
	if (m_mouseFlag & MOUSE_FLAG_DOWN)
	{
		ChangeSplitState(SplitStatePressed);
	}
	else
	{
		ChangeSplitState(SplitStateHot);
	}
}

void ICtrlSplitBarImpl::OnMouseLeave(POINT pt)
{
	ChangeSplitState(SplitStateNormal);
}

void ICtrlSplitBarImpl::OnLButtonDown(POINT pt)
{
	m_ptClick = pt;
	m_bTracking = TRUE;

	m_mouseFlag |= MOUSE_FLAG_DOWN;
	ChangeSplitState(SplitStatePressed);
}

void ICtrlSplitBarImpl::OnLButtonUp(POINT pt)
{
	m_bTracking = FALSE;
	m_mouseFlag &= ~MOUSE_FLAG_DOWN;
	if (IsMousehover())
	{
		ChangeSplitState(SplitStateHot);
	}
	else
	{
		ChangeSplitState(SplitStateNormal);
	}
}

void ICtrlSplitBarImpl::OnWindowFinalCreate()
{

}


IPropertyCursor* ICtrlSplitBarImpl::OnSetCursor(POINT pt)
{
	if ((m_enumSplitSate!=SplitStateHot && m_enumSplitSate!=SplitStatePressed))
	{
		return NULL;
	}
	return m_pCursor;
}


void ICtrlSplitBarImpl::SetSplitterType(BOOL bHorz)
{
	if (m_pIsHorz == NULL)
	{
		return;
	}
	m_pIsHorz->SetValue(bHorz);
}

void ICtrlSplitBarImpl::SetSplitterHorzMin(int nTopMin, int nBottomMin)
{
	if (m_pRightBottomMin == NULL || m_pTopLeftMin == NULL)
		return;
	
	m_pTopLeftMin->SetValue(nTopMin);
	m_pRightBottomMin->SetValue(nBottomMin);

	Relayout();

}

void ICtrlSplitBarImpl::SetSplitterVertMin(int nLeftMin, int nRightMin)
{
	if (m_pRightBottomMin == NULL || m_pTopLeftMin == NULL)
		return;

	m_pTopLeftMin->SetValue(nLeftMin);
	m_pRightBottomMin->SetValue(nRightMin);

	Relayout();
}

int ICtrlSplitBarImpl::GetTopLeftMin()
{
	if(m_pTopLeftMin == NULL)
		return 0;

	return m_pTopLeftMin->GetValue();
}

int ICtrlSplitBarImpl::GetBottomRightMin()
{
	if (m_pRightBottomMin == NULL)
		return 0;

	return m_pRightBottomMin->GetValue();
}

int ICtrlSplitBarImpl::GetGraphLength()
{
	if (m_pGraphLength == NULL)
		return 0;

	return m_pGraphLength->GetValue();
}

void ICtrlSplitBarImpl::SetGraphLength(int nGraphLength, BOOL bRedraw)
{
	m_pGraphLength->SetValue(nGraphLength);
	this->RedrawControl(bRedraw);
}

void ICtrlSplitBarImpl::ChangeSplitState(SPLITBARSTATE state)
{
	if(state != m_enumSplitSate)
	{
		m_enumSplitSate = state;
		RedrawControl(true);
	}
}

void ICtrlSplitBarImpl::OnMouseDragging(POINT pt)
{
	if (!m_bTracking)
		return;

	if (m_pWindowBase == NULL || m_pTopLeftName == NULL || m_pTopLeftName->GetLength()==0 ||
		m_pRightBottomName == NULL || m_pRightBottomName->GetLength()==0)
		return;

	WCHAR* tlNameW = m_pTopLeftName->GetString();
	char *tlName = (char *)malloc(sizeof(char)*(2 * wcslen(tlNameW)+1));
	memset(tlName , 0 , 2 * wcslen(tlNameW)+1 );
	w2c(tlName,tlNameW,2 * wcslen(tlNameW)+1);

	WCHAR* rbNameW = m_pRightBottomName->GetString();
	char *rbName = (char *)malloc(sizeof(char)*(2 * wcslen(rbNameW)+1));
	memset(rbName , 0 , 2 * wcslen(rbNameW)+1 );
	w2c(rbName,rbNameW,2 * wcslen(rbNameW)+1);

	/*IControlBase* pTopLeftPanel = m_pWindowBase->GetControl((char*)m_pTopLeftName->GetString());
	IControlBase* pRightBottomPanel = m_pWindowBase->GetControl((char*)m_pRightBottomName->GetString());*/
	IControlBase* pTopLeftPanel = m_pWindowBase->GetControl(tlName);
	IControlBase* pRightBottomPanel = m_pWindowBase->GetControl(rbName);
	if (pTopLeftPanel == NULL || pRightBottomPanel == NULL)
		return;

	POINT ptMove;
	ptMove.x = pt.x - m_ptClick.x;
	ptMove.y = pt.y - m_ptClick.y;

	RECT rcTopLeftPanel = pTopLeftPanel->GetWindowRect();
	RECT rcRightBottomPanel = pRightBottomPanel->GetWindowRect();
	RECT rcSplit = this->GetWindowRect();

	if (!m_pIsHorz->GetValue())
	{
		rcTopLeftPanel.right +=ptMove.x;
		rcRightBottomPanel.left +=ptMove.x;

		rcSplit.left += ptMove.x;
		rcSplit.right += ptMove.x;

		if (ptMove.x < 0)
		{
			//decrease left pane
			int iTest = RECT_WIDTH(rcTopLeftPanel) - m_pTopLeftMin->GetValue();
			if (iTest < 0)
			{
				rcTopLeftPanel.right -= iTest;
				rcRightBottomPanel.left -= iTest;

				rcSplit.left -= iTest;
				rcSplit.right -= iTest;
			}
		}
		else
		{
			//decrease right pane
			int iTest = RECT_WIDTH(rcRightBottomPanel) - m_pRightBottomMin->GetValue();
			if (iTest < 0)
			{
				rcTopLeftPanel.right += iTest;
				rcRightBottomPanel.left += iTest;

				rcSplit.left += iTest;
				rcSplit.right += iTest;
			}
		}

	}
	else
	{
		rcTopLeftPanel.bottom += ptMove.y;
		rcRightBottomPanel.top += ptMove.y;

		rcSplit.top += ptMove.y;
		rcSplit.bottom += ptMove.y;

		if (ptMove.y <0)
		{
			//decrease top pane
			int iTest = RECT_HEIGHT(rcTopLeftPanel) - m_pTopLeftMin->GetValue();
			if(iTest < 0)
			{
				rcTopLeftPanel.bottom -= iTest;
				rcRightBottomPanel.top -= iTest;

				rcSplit.top -= iTest;
				rcSplit.bottom -= iTest;
			}
		}
		else
		{
			//decrease bottom pane
			int iTest = RECT_HEIGHT(rcRightBottomPanel) - m_pRightBottomMin->GetValue();
			if (iTest < 0)
			{
				rcTopLeftPanel.bottom += iTest;
				rcRightBottomPanel.top += iTest;

				rcSplit.top += iTest;
				rcSplit.bottom += iTest;
			}
		}
	}

	this->SetWindowRectLayoutWithChild(rcSplit);
	pTopLeftPanel->SetWindowRectLayoutWithChild(rcTopLeftPanel);
	pRightBottomPanel->SetWindowRectLayoutWithChild(rcRightBottomPanel);
}


// ����϶�����������̧����ꡣpDragCtrl����ק��Դ�ؼ�
void ICtrlSplitBarImpl::OnDragStop(IControlBase* pDragCtrl, POINT pt, WPARAM wParam, LPARAM lParam)
{

}

void ICtrlSplitBarImpl::Relayout()
{
	if (m_pWindowBase == NULL || m_pTopLeftName == NULL || m_pTopLeftName->GetLength()==0 ||
		m_pRightBottomName == NULL || m_pRightBottomName->GetLength()==0)
		return;

	WCHAR* tlNameW = m_pTopLeftName->GetString();
	char *tlName = (char *)malloc(sizeof(char)*(2 * wcslen(tlNameW)+1));
	memset(tlName , 0 , 2 * wcslen(tlNameW)+1 );
	w2c(tlName,tlNameW,2 * wcslen(tlNameW)+1);

	WCHAR* rbNameW = m_pRightBottomName->GetString();
	char *rbName = (char *)malloc(sizeof(char)*(2 * wcslen(rbNameW)+1));
	memset(rbName , 0 , 2 * wcslen(rbNameW)+1 );
	w2c(rbName,rbNameW,2 * wcslen(rbNameW)+1);


	IControlBase* pTopLeftPanel = m_pWindowBase->GetControl(tlName);
	IControlBase* pRightBottomPanel = m_pWindowBase->GetControl(rbName);
	if (pTopLeftPanel == NULL || pRightBottomPanel == NULL)
		return;

	RECT rcTopLeftPanel = pTopLeftPanel->GetWindowRect();
	RECT rcRightBottomPanel = pRightBottomPanel->GetWindowRect();
	RECT rcSplit = this->GetWindowRect();

	if (!m_pIsHorz->GetValue())
	{
		//�����������
		int iTest = RECT_WIDTH(rcTopLeftPanel) - m_pTopLeftMin->GetValue();
		if (iTest < 0)
		{
			rcTopLeftPanel.right -= iTest;
			rcRightBottomPanel.left -= iTest;

			rcSplit.left -= iTest;
			rcSplit.right -= iTest;
		}

		//�����Ҳ�����
		iTest = RECT_WIDTH(rcRightBottomPanel) - m_pRightBottomMin->GetValue();
		if (iTest < 0)
		{
			rcTopLeftPanel.right += iTest;
			rcRightBottomPanel.left += iTest;

			rcSplit.left += iTest;
			rcSplit.right += iTest;
		}
	}
	else
	{
		//�����Ϸ�����
		int iTest = RECT_HEIGHT(rcTopLeftPanel) - m_pTopLeftMin->GetValue();
		if(iTest < 0)
		{
			rcTopLeftPanel.bottom -= iTest;
			rcRightBottomPanel.top -= iTest;

			rcSplit.top -= iTest;
			rcSplit.bottom -= iTest;
		}

		//�����·�����
		iTest = RECT_HEIGHT(rcRightBottomPanel) - m_pRightBottomMin->GetValue();
		if (iTest < 0)
		{
			rcTopLeftPanel.bottom += iTest;
			rcRightBottomPanel.top += iTest;

			rcSplit.top += iTest;
			rcSplit.bottom += iTest;
		}

	}

	this->SetWindowRectLayoutWithChild(rcSplit);
	pTopLeftPanel->SetWindowRectLayoutWithChild(rcTopLeftPanel);
	pRightBottomPanel->SetWindowRectLayoutWithChild(rcRightBottomPanel);

}

char* ICtrlSplitBarImpl::w2c(char *pcstr,const wchar_t *pwstr, size_t len)
{
	int nlength=wcslen(pwstr);

	//��ȡת����ĳ���

	int nbytes = WideCharToMultiByte( 0, // specify the code page used to perform the conversion
		0,         // no special flags to handle unmapped characters
		pwstr,     // wide character string to convert
		nlength,   // the number of wide characters in that string
		NULL,      // no output buffer given, we just want to know how long it needs to be
		0,
		NULL,      // no replacement character given
		NULL );    // we don't want to know if a character didn't make it through the translation

	// make sure the buffer is big enough for this, making it larger if necessary

	if(nbytes>len)   nbytes=len;

	WideCharToMultiByte( 0, // specify the code page used to perform the conversion
		0,         // no special flags to handle unmapped characters
		pwstr,   // wide character string to convert
		nlength,   // the number of wide characters in that string
		pcstr, // put the output ascii characters at the end of the buffer
		nbytes,                           // there is at least this much space there
		NULL,      // no replacement character given
		NULL);

	return pcstr ;
}